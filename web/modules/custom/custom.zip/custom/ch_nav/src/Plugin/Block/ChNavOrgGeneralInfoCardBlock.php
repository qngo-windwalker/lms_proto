<?php

namespace Drupal\ch_nav\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'ChNavOrgGeneralInfoCardBlock' block.
 *
 * @Block(
 *  id = "ch_nav_org_general_info_card_block",
 *  admin_label = @Translation("Organization General Info"),
 * )
 */
class ChNavOrgGeneralInfoCardBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $content = '';
    if (isset($this->configuration['group'])) {
      /** @var \Drupal\group\Entity\Group $group */
      $group = $this->configuration['group'];
      $orgOwner = $group->getOwner();
      $content = '<div class="row">';
      $content .= '<div class="col-md-6">' . $this->getAddressCard($orgOwner) . '</div>';
      $content .= '<div class="col-md-6">' . $this->getInfoCard($orgOwner) . '</div>';
      $content .= '</div>';
    }

    $build = [];
    $build['ch_nav_org_general_info_card_block']['#markup'] = $content;
    return $build;
  }

  private function getInfoCard($orgOwner) {
    $ownerEmail = $this->getEntityFieldValue($orgOwner, 'mail');
    $content = '<p>Name: ' . $this->getEntityFieldValue($orgOwner, 'field_first_name') . ' ' . $this->getEntityFieldValue($orgOwner, 'field_last_name') . '</p>';
    $content .= '<p>Email: <a href="mailto:' . $ownerEmail . '" />' . $ownerEmail . '</a></p>';
    $content .= '<p>Company Role: ' . $this->getEntityFieldValue($orgOwner, 'field_clearinghouse_role') . '</p>';
    $build = [];
    $build['#theme'] = 'wind_bootstrap_block_card';
    $build['#label'] = 'Admin';
    $build['#content'] = $content;
    return render($build);
  }

  private function getAddressCard($orgOwner) {
    $content = '<p>' . $this->getEntityFieldValue($orgOwner, 'field_street_address') . '</p>';
    $content .= '<p>' . $this->getEntityFieldValue($orgOwner, 'field_city') . ', ' . $this->getEntityFieldValue($orgOwner, 'field_us_state') .  ' ' . $this->getEntityFieldValue($orgOwner, 'field_postal_zip_code') . '</p>';
    $build = [];
    $build['#theme'] = 'wind_bootstrap_block_card';
    $build['#label'] = 'Address';
    $build['#content'] = $content;
    return render($build);
  }

  private function getEntityFieldValue($entity, $fieldName) {
    if($entity->hasField($fieldName)){
      return $entity->get($fieldName)->getString();
    }
    return '';
  }

}
