<?php

/**
 * Enable custom theme option in *.routing.yml. Example:
 *  options:
 *     _custom_theme: 'cn_theme'
 * See wind.services.yml for priority value.
 *
 * Giving credit:
 * @see https://webomelette.com/choose-your-theme-dynamically-drupal-8-theme-negotiation
 */

namespace Drupal\ch_nav\Theme;

use Drupal\Core\Routing\RouteMatchInterface;
use Symfony\Component\Routing\Route;
use Drupal\Core\Theme\ThemeNegotiatorInterface;

class ChNavThemeNegotiator implements ThemeNegotiatorInterface{

  private $customThemeName = 'cn_theme';
  /**
   * {@inheritdoc}
   */
  public function applies(RouteMatchInterface $route_match) {
    $route = $route_match->getRouteObject();

    // In case of missing page
    if (is_null($route)) {
      return $this->customThemeName;
    }

    if (!$route instanceof Route) {
      return FALSE;
    }
    return $this->getThemeByRouteName($route_match);
  }

  /**
   * {@inheritdoc}
   */
  public function determineActiveTheme(RouteMatchInterface $route_match) {

    return $this->getThemeByRouteName($route_match);
  }

  private function getThemeByRouteName(RouteMatchInterface $route_match) {
    // Filter out pages to use our custom theme.
    switch ($route_match->getRouteName()){
      case 'opigno_group_manager.manager.index':
      case 'view.group_members.page_1':
      case 'entity.group.canonical':
        return 'seven';
        break;

        // For user/{user}
      case 'entity.user.canonical':
        // For user/{user}/edit
      case 'entity.user.edit_form':
        $user = \Drupal::currentUser();
        if ($user->id() == 1) {
          return 'seven';
        }
        $userRoles = $user->getRoles();
        if (in_array('administrator', $userRoles)) {
          return 'seven';
        }
        return $this->customThemeName;
        break;

      // null for missing page.
      case null:
      case 'wind.403':
      case 'wind.404':
      case 'user.login':
      case 'user.pass':
      case 'user.register':
      case 'user.page':
      case 'user.cancel_confirm':
      case 'user.reset':
      case 'user.reset.login':
      case 'user.reset.form':
      case 'user.cancel_confirm':
      case 'entity.group.canonical':
      case 'view.frontpage.page_1':
      case 'wind_lms.answer_form':
      case 'wind_lms.course':
      case 'wind_lms.course.users':
      case 'wind_lms.course.adduser':
      case 'wind_lms.org.adduser':
      case 'wind_lms.course.adduser':
      case 'wind_lms.course.user.add':
      case 'wind_lms.course.user.remove':
        return $this->customThemeName;
        break;
    }
    return FALSE;
  }
}
