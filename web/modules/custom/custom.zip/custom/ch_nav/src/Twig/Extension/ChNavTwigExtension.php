<?php

namespace Drupal\ch_nav\Twig\Extension;

use Drupal\Core\Render\Markup;
use Drupal\Core\Link;
use Drupal\Core\Url;

class ChNavTwigExtension extends \Twig_Extension {

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'ch_nav';
  }

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [
      new \Twig_SimpleFunction('getMainMenu', [$this, 'getMainMenu']),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getPath($name, $parameters = [], $options = []) {
    $options['absolute'] = FALSE;
    return $this->urlGenerator->generateFromRoute($name, $parameters, $options);
  }

  public function getMainMenu() {
    $currentUser = \Drupal::currentUser();
    if ($currentUser->isAnonymous()) {
      return '';
    }
    $orgGroup = ch_nav_get_user_group_organization($currentUser);
    $orgUrl = Url::fromUserInput(
      "/org/{$orgGroup->id()}",
      array(
        'attributes' => array('class' => 'nav-link')
      )
    );
    $helpUrl = Url::fromUserInput(
      "/help",
      array('attributes' => array('class' => 'nav-link'))
    );
    $dashLink = Link::fromTextAndUrl('Dashboard', Url::fromUserInput("/dashboard", array('attributes' => array('class' => 'nav-link'))))->toString();
    $orgLink = Link::fromTextAndUrl(Markup::create('User'), $orgUrl)->toString();
    return [
      '#markup' => $dashLink . $orgLink . Link::fromTextAndUrl('Help', $helpUrl)->toString()
    ];
  }
}
