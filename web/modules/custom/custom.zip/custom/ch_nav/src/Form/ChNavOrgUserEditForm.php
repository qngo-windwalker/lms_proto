<?php

namespace Drupal\ch_nav\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\user\Entity\User;
use Drupal\Core\Access\AccessResult;

class ChNavOrgUserEditForm extends FormBase {

  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;
   /** @var \Drupal\user\Entity\User $user */
  private $user;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_org_user_edit';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL, User $user = NULL) {
    $this->group = $group;
    $this->user = $user;
    $userGroupRoleValue = $this->getUserGroupRoleValue($user, $group);
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : "internal:/org/{$group->id()}";

    $form['#tree'] = TRUE;
    $form['role'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Role'),
    ];
    $form['role']['role_wrapper'] = [
      '#type' => 'container',
      '#attributes' => array(
        'class' => ['card-columns']
      ),
    ];

    $roleOptions = $this->getGroupRoleOptions($group);
    foreach ($roleOptions as $key => $roleLabel) {
      $desc = '';
      switch ($roleLabel) {
        case 'Administrator':
        case 'Admin':
          $desc = '<p>Administer the group, its content and members <br /> <em class="text-warning">Warning: Give to trusted roles only; this permission has security implications.</em></p>';
          break;
        case 'Member':
          $desc = 'The default role for anyone in the group.';
          break;
        case 'User manager':
          $desc = 'Administer individual members';
          break;
        case 'Content manager':
          $desc = 'Administer course';
          break;
      }
      $form['role']['role_wrapper'][$key] = [
        '#type' => 'radio',
        '#title' => $roleLabel,
        '#description' => $desc,
        '#return_value' => $key,
//        '#options' => array($key => $roleLabel),
        '#attributes' => array(
//          'name' => \Drupal\Component\Utility\Html::getUniqueId('edit-group-role')
          'name' => 'edit-group-role'
        ),
        '#prefix' => '<div class="card bg-transparent"><div class="card-body">',
        '#suffix' => '</div></div>',
      ];
      if ($key == $userGroupRoleValue) {
        $form['role']['role_wrapper'][$key]['#default_value'] = $key;
      }
    }

    $form['status'] = [
      '#type' => 'radios',
      '#title' => $this->t('Status'),
      '#default_value' => $user->isActive() ? 1 : 0,
      '#options' => array(
        '0' => 'Inactive',
        '1' => 'Active',
      )
    ];

    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Save',
      '#attributes' => array(
        'class' => ['btn', 'btn-primary']
      )
    ];
    return $form;
  }

  /**
   * @see \Drupal\image\Controller\QuickEditImageController->upload() to see how to implement Ajax.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $submittedStatus = $form_state->getValue('status');
    $hasChange = false;
    if($submittedStatus != $form['status']['#default_value']){
      if ($submittedStatus) {
        $this->user->activate();
      } else {
        $this->user->block();
      }
      $this->user->save();
      $hasChange = true;
    }
    $selectedRole = $this->getSelectedRoleValue($form_state);
    if($selectedRole){
      $membership = $this->group->getMember($this->user);
      $roles = $membership->getRoles();
      // If user doesn't have the selected role.
      if (!isset($roles[$selectedRole])) {
        $groupContent = $membership->getGroupContent();
        $groupContent->set('group_roles', ['target_id' => $selectedRole]);
        $groupContent->save();
        $hasChange = true;
      } else {
        if($selectedRole == 'organization-member'){
          // Since member can have multiple role and we only want on most basic role for this user
          // this will remove all previous roles.
          $groupContent = $membership->getGroupContent();
          $groupContent->set('group_roles', ['target_id' => $selectedRole]);
          $groupContent->save();
          $hasChange = true;
        }
      }
    }

    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUserInput($destination));
    } else {
      $form_state->setRedirect('<front>');
    }

    $messenger = \Drupal::messenger();
    if ($hasChange) {
      $messenger->addMessage(t('The changes to %user account have been saved.', [
        '%user' => $this->user->getUsername(),
        '%label' => $this->group->label(),
      ]), $messenger::TYPE_STATUS);
    } else {
      $messenger->addMessage(t('No change to %user account has been made.', [
        '%user' => $this->user->getUsername(),
        '%label' => $this->group->label(),
      ]), $messenger::TYPE_WARNING);
    }
  }

  public function access( Group $group, User $user) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

  private function getSelectedRoleValue($form_state) {
    // Todo: Find out why our custom radio form element is not captured by Drupal's $form_state.
    $postEditGroupRole = $_POST['edit-group-role'];
    $role = $form_state->getValue('role');
    if(isset($role['role_wrapper'][$postEditGroupRole])) {
      return $postEditGroupRole;
    }
    return false;
  }

  /**
   * @param \Drupal\user\Entity\User $user
   * @param \Drupal\group\Entity\Group $group
   */
  private function getUserGroupRoleValue(User $user, Group $group) {
    $membership = $group->getMember($user);
    /** @var \Drupal\group\Entity\GroupRole[] $groupRoles */
    $groupRoles = $membership->getRoles();
    if (count($groupRoles) > 1) {
      unset($groupRoles['organization-member']);
    }
    $groupRole = array_shift($groupRoles);
    return $groupRole->id();
  }

  private function getGroupRoleOptions(Group $group) {
    $options = [];
    $groupRoles = \Drupal::entityTypeManager()->getStorage('group_role')->loadByProperties([
      'group_type' => $group->getGroupType()->id(),
//      'internal' => false
    ]);

    foreach ($groupRoles as $groupRole) {
      $groupRoleLabel = $groupRole->label();
      // Filter out the unwanted role.
      switch ($groupRoleLabel) {
        case 'Administrator':
        case 'Anonymous':
        case 'Outsider':
          continue 2;
              break;
      }
      $options[$groupRole->id()] = $groupRole->label();
    }

    return $options;
  }
}
