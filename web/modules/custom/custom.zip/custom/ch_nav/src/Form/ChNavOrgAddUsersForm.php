<?php

namespace Drupal\ch_nav\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\user\Entity\User;
use Drupal\Core\Access\AccessResult;
use Drupal\invite\Entity\Invite;

class ChNavOrgAddUsersForm extends FormBase {

  /**
   * @var \Drupal\group\Entity\Group
   */
  private $group;
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_org_adduser';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL) {
    $this->group = $group;
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : "internal:/org/{$group->id()}";
    $form['#tree'] = TRUE;
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE,
      '#description' => $this->t('Type the email address to add new user. During signup they will enter their full name.'),
    ];
    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Send Invite',
      '#attributes' => array(
        'class' => ['btn', 'btn-primary']
      )
    ];
    return $form;
  }

  /**
   * @see \Drupal\image\Controller\QuickEditImageController->upload() to see how to implement Ajax.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Get the owner of this group in case where an admin administering is NOT a member.
    $groupOwner = $this->group->getOwner();
    // The machine name that was created at admin/structure/invite_type
    $invite_type = 'organization_invite';
    $invite = Invite::create(array('type' => $invite_type));
    $invite->setPlugin('invite_by_email');
    $invite->field_invite_email_address->value = $form_state->getValue('email');
    $invite->setOwner($groupOwner);
    $invite->save();
    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUserInput($destination));
    } else {
      $form_state->setRedirect('<front>');
    }

    $messenger = \Drupal::messenger();
    $messenger->addMessage(t('An email invitation has been sent to %email.', [
      '%email' => $form_state->getValue('email'),
    ]), $messenger::TYPE_STATUS);
  }

  public function access( Group $group) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

}
