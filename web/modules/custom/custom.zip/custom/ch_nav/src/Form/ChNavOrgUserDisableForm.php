<?php

namespace Drupal\ch_nav\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Url;
use Drupal\user\Entity\User;
use Drupal\group\Entity\Group;

class ChNavOrgUserDisableForm extends FormBase {

  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;
  /**
   * @var \Drupal\user\Entity\User $user
   */
  private $user;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_org_user_disable';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL, User $user = NULL) {
    $this->group = $group;
    $this->user = $user;
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : 'internal:/';
    $form['#tree'] = TRUE;
    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Disable',
      '#attributes' => array(
        'class' => ['btn', 'btn-danger']
      )
    ];
    return $form;
  }

  /**
   * @see \Drupal\image\Controller\QuickEditImageController->upload() to see how to implement Ajax.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Blocking
    $this->user->block();
    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUserInput($destination));
    } else {
      $form_state->setRedirect('<front>');
    }
    $messenger = \Drupal::messenger();
    $messenger->addMessage(t('The username %user has been disabled.', [
      '%user' => $this->user->getUsername(),
      '%label' => $this->group->label(),
    ]), $messenger::TYPE_STATUS);
  }

  public function access( Group $group) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

  public function getTitle(Group $group, User $user) {
    return $this->t('Are you sure you want to disable %user?', [
      '%user' => $user->getUsername(),
      '%label' => $group->label(),
    ]);
  }

}
