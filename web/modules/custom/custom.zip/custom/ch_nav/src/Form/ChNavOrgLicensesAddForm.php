<?php

namespace Drupal\ch_nav\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\user\Entity\User;
use Drupal\Core\Access\AccessResult;

class ChNavOrgLicensesAddForm extends FormBase {

  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_org_addlicenses';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL) {
    $this->group = $group;
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : 'internal:/';
    $form['#tree'] = TRUE;
    $form['addition'] = [
      '#type' => 'number',
      '#title' => $this->t('Licenses'),
      '#attributes' => array(
        'min' => 0
      )
    ];
    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Authorize Purchase',
      '#attributes' => array(
        'class' => ['btn', 'btn-primary']
      )
    ];
    return $form;
  }

  /**
   * @see \Drupal\image\Controller\QuickEditImageController->upload() to see how to implement Ajax.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $owner = $this->group->getOwner();
    if (!$owner) {
    }
    $newAdditionVal = (int)$form_state->getValue('addition');
    if ($newAdditionVal) {
      $currentLicenses = (int)$owner->get('field_number_of_users')->getString();
      $total = $newAdditionVal + $currentLicenses;
      $user = User::load($owner->id());
      $user->set('field_number_of_users', ['value' => $total]);
      $user->save();
      $messenger = \Drupal::messenger();
      if ($newAdditionVal == 1) {
        $messenger->addMessage(t('Additional license has been added.', []), $messenger::TYPE_STATUS);
      } elseif ($newAdditionVal > 1) {
        $messenger->addMessage(t('Additional licenses have been added.', []), $messenger::TYPE_STATUS);
      }
    }

    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUserInput($destination));
    } else {
      $form_state->setRedirect('<front>');
    }
  }

  public function access(Group $group) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

  public function getTitle(Group $group) {
    return $this->t('Add Licenses for %label', [
      '%label' => $group->label(),
    ]);
  }

}
