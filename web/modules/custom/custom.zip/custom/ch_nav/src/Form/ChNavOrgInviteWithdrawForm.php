<?php

namespace Drupal\ch_nav\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\invite\Entity\Invite;
use Drupal\user\Entity\User;
use Drupal\Core\Access\AccessResult;

class ChNavOrgInviteWithdrawForm extends FormBase {

  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;
  /** @var \Drupal\invite\Entity\Invite $invite */
  private $invite;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_org_invite_withdraw';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL, Invite $invite = NULL) {
    $this->group = $group;
    $this->invite = $invite;
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : "internal:/org/{$group->id()}";
    $form['#tree'] = TRUE;
    $form['role'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Role'),
    ];
    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Withdraw',
      '#attributes' => array(
        'class' => ['btn', 'btn-danger']
      )
    ];
    return $form;
  }

  /**
   * @see \Drupal\image\Controller\QuickEditImageController->upload() to see how to implement Ajax.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Get the email address before we delete the entity.
    $inviteeEmail = $this->invite->get('field_invite_email_address')->getString();
    $this->invite->delete();

    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUserInput($destination));
    } else {
      $form_state->setRedirect('<front>');
    }

    $messenger = \Drupal::messenger();
    $messenger->addMessage(t('The invite to %email has been withdrawn.', ['%email' => $inviteeEmail]), $messenger::TYPE_STATUS);
  }

  public function access( Group $group, Invite $invite = NULL) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

  public function getTitle(Group $group, Invite $invite) {
    return t('Are you sure you want to withdraw the invite to %email.', [ '%email' => $invite->get('field_invite_email_address')->getString()]);
  }

  /**
   * @param \Drupal\user\Entity\User $invite
   * @param \Drupal\group\Entity\Group $group
   */
  private function getUserGroupRoleValue(User $invite, Group $group) {
    $membership = $group->getMember($invite);
    /** @var \Drupal\group\Entity\GroupRole[] $groupRoles */
    $groupRoles = $membership->getRoles();
    if (count($groupRoles) > 1) {
      unset($groupRoles['organization-member']);
    }
    $groupRole = array_shift($groupRoles);
    return $groupRole->id();
  }

  private function getGroupRoleOptions(Group $group) {
    $options = [];
    $groupRoles = \Drupal::entityTypeManager()->getStorage('group_role')->loadByProperties([
      'group_type' => $group->getGroupType()->id(),
//      'internal' => false
    ]);

    foreach ($groupRoles as $groupRole) {
      $groupRoleLabel = $groupRole->label();
      // Filter out the unwanted role.
      switch ($groupRoleLabel) {
        case 'Administrator':
        case 'Anonymous':
        case 'Outsider':
          continue 2;
          break;
      }
      $options[$groupRole->id()] = $groupRole->label();
    }

    return $options;
  }
}
