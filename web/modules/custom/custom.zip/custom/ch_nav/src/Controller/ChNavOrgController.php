<?php

namespace Drupal\ch_nav\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\group\Entity\Group;
use Drupal\Core\Render\Markup;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Access\AccessResult;

class ChNavOrgController extends ControllerBase{
  public function getContent(Group $group) {
    $markup = $this->getInfoSection($group);
    $markup .= $this->getUserSection($group);
    return [
      '#markup' => $markup,
    ];
  }

  public function getTitle(Group $group) {
    return $group->label();
  }

  private function getInfoSection(Group $group) {
    $orgInfoBlock = wind_load_plugin_block('ch_nav_org_general_info_card_block',  array('group' => $group));
    $markup = '<div class="col-12-md">';
    $markup .= render($orgInfoBlock );
    $markup .= '</div>';
    return $markup;
  }

  private function getUserSection(Group $group) {
    $url = Url::fromUserInput(
      "/org/{$group->id()}/adduser",
      array(
        'query' => ['destination' => "/org/{$group->id()}"],
        'attributes' => array('class' => 'btn btn-info'))
    );
    $linkContent = '<i class="fas fa-plus-circle"></i> Add User';
    $renderedAnchorContent = render($linkContent);

    $table = $this->getDataTableRenderable('user-tbl', '/chnav-datatable/org/' . $group->id(). '/users');
    $markup = '<div class="col-12-md">';
    $markup .= '<h3>Users</h3>';
    $markup .= render($table);
    $markup .= Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
    $markup .= '</div>';
    return $markup;
  }

  private function getDataTableRenderable($tableElemntId, $datatableURL) {
    $header = [
      array('data' => 'Status', 'class' => 'user-status-header'),
      array('data' => 'User Id', 'class' => 'user-id-header'),
      array('data' => 'First Name', 'class' => 'user-first-name-header'),
      array('data' => 'Last Name', 'class' => 'user-last-name-header'),
      array('data' => 'Email', 'class' => 'user-email-header'),
      array('data' => 'Role', 'class' => 'user-group-role-header'),
      array('data' => 'Last Login', 'class' => 'user-last-login-header'),
      array('data' => 'Operations', 'class' => 'user-operations-header'),
    ];

    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => array(),
      '#empty' => t('There are no data.'),
      '#attributes' => array(
        'id' => $tableElemntId,
        'class' => array('table' ,'table-wind-theme-strip')
      ),
      '#attached' => array(
        'library' => array(
          'ch_nav/org'
        ),
        'drupalSettings' => array(
          'ch_nav' => array(
            'datatableURL' => $datatableURL,
            'datatableElementId' => '#' . $tableElemntId
          )
        )
      )
    ];
  }

  /**
   * Check the access to this form.
   */
  public function access(Group $group) {
    $user = \Drupal::currentUser();
    if (wind_does_user_has_sudo($user)){
      return AccessResult::allowed();
    }

    if($group->getMember(\Drupal::currentUser())){
      return AccessResult::allowed();
    }
    return AccessResult::neutral();
  }
}
