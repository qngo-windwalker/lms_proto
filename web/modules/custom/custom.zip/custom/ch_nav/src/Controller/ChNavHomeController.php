<?php

namespace Drupal\ch_nav\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;

class ChNavHomeController extends ControllerBase{

  /*
   * path: home
   */
  public function getContent() {
    $currentUser = \Drupal::currentUser();
    $response = $currentUser->isAnonymous() ? new RedirectResponse('/user/login') :  new RedirectResponse('/dashboard');
    $response->send();
  }
}
