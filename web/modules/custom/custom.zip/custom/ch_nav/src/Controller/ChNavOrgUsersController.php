<?php

namespace Drupal\ch_nav\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\group\Entity\Group;

class ChNavOrgUsersController extends ControllerBase{

  public function getContent(Group $group) {
    $table = $this->getDataTableRenderable('user-tbl', '/chnav-datatable/org/' . $group->id(). '/users', 'user-tbl');
    $markup = '<div class="col-12-md">';
    $markup .= render($table);
    $markup .= '</div>';

    return [
      '#markup' => $markup,
    ];
  }

  private function getDataTableRenderable($tableElemntId, $datatableURL) {
    $header = [
      array('data' => 'Active', 'class' => 'node-first-name-header'),
      array('data' => 'First Name', 'class' => 'node-first-name-header'),
      array('data' => 'Last Name', 'class' => 'node-last-name-header'),
      array('data' => 'Email', 'class' => 'node-email-header'),
      array('data' => 'Last Login', 'class' => 'node-last-login-header'),
      array('data' => 'Last Accessed', 'class' => 'node-last-accessed-header'),
      array('data' => 'Operations', 'class' => 'node-operations-header'),
    ];

    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => array(),
      '#empty' => t('There are no data.'),
      '#attributes' => array(
        'id' => $tableElemntId,
        'class' => array('table' ,'table-wind-theme-strip')
      ),
      '#attached' => array(
        'library' => array(
          'ch_nav/datatable_users'
        ),
        'drupalSettings' => array(
          'ch_nav' => array(
            'datatableURL' => $datatableURL,
            'datatableElementId' => '#' . $tableElemntId
          )
        )
      )
    ];
  }
}
