<?php

namespace Drupal\ch_nav\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;

class ChNavDashboardController extends ControllerBase{

  public function getContent() {
    $currentUser = \Drupal::currentUser();
    if ($currentUser->isAnonymous()) {
      $response = new RedirectResponse('/user/login');
      $response->send();
    }
    $learningPathGroups = wind_lms_get_user_group_learning_paths($currentUser);
    $learningPathGroups = wind_lms_get_all_group_learning_path();
//    $block = wind_load_entity_block_with_bootstrap_card('cn_theme_wind_intro_block');
    $block = wind_load_entity_block_with_bootstrap_card('organizationinvite');
    $windIntroBlock = wind_load_plugin_block('wind_intro_block');
    $membershipBlock = wind_load_plugin_block('wind_lms_group_membership_block');
    $windLmsMyTrainingBlock = wind_load_plugin_block('wind_lms_my_training');
    $wind_lmd_course_user_count_block = wind_load_plugin_block('wind_lmd_course_user_count_block', array('groups' => $learningPathGroups));
    $chNavHelpRequestBlock = wind_load_plugin_block('ch_nav_help_request_summary_block', array('groups' => $learningPathGroups));
    $build = [];
    $build[] = [
      '#type' => 'container',
      '#attributes' => [
        'class' => ['card-columns'],
      ],
      'left' => [
        '#markup' => render($windIntroBlock),
      ],
      [
          '#markup' => render($windLmsMyTrainingBlock),
      ],
      [
        '#markup' => render($chNavHelpRequestBlock),
      ],
      [
          '#markup' => render($wind_lmd_course_user_count_block),
      ],
//      [
//        '#markup' => render(wind_load_plugin_block('wind_lms_catalog_block')),
//      ],
      [
        '#markup' => render($membershipBlock),
      ],
      [
        '#markup' => render($block),
      ],

//      [
//        '#markup' => wind_load_entity_block_with_bootstrap_card('cn_theme_wind_intro_block', true),
//      ],
    ];

    return $build;
  }

}
