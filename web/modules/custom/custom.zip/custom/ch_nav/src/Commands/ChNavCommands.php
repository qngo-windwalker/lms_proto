<?php

namespace Drupal\ch_nav\Commands;

use Consolidation\OutputFormatters\StructuredData\RowsOfFields;
use Drush\Commands\DrushCommands;
use Drupal\group\Entity\Group;
use Drupal\user\Entity\User;

/**
 * A Drush commandfile.
 *
 * In addition to this file, you need a drush.services.yml
 * in root of your module, and a composer.json file that provides the name
 * of the services file to use.
 *
 * See these files for an example of injecting Drupal services:
 *   - http://cgit.drupalcode.org/devel/tree/src/Commands/DevelCommands.php
 *   - http://cgit.drupalcode.org/devel/tree/drush.services.yml
 */
class ChNavCommands extends DrushCommands {

  /**
   * Create a new learner user and enroll to all of the training.
   *
   * @param $pass
   *
   * @command ch_nav:createTestUsers
   * @aliases chnavctu
   */
  public function createTestUsers($pass){
    $this->configTheFirstUser();
    $users = array(
      array(
        'name' => 'test_ws',
        'pass' => $pass,
        'mail' => 'shawnwhiddon@gmail.com',
        'first_name' => 'Shawn',
        'last_name' => 'Whiddon',
        'title' => 'President',
        'clearinghouse_role' => 'Employer',
        'company' => 'Truckway',
        'street_address' => '1429 New Creek Road',
        'city' => 'Fort Wayne',
        'us_state' => 'IN',
        'postal_zip_code' => '26802',
        'phone' => '2602182793',
        'country' => 'US',
        'group_account' => true,
        'number_of_users' => 1,
      ),
      array(
        'name' => 'test_pj',
        'pass' => $pass,
        'mail' => 'jpate@freightful.com',
        'first_name' => 'Jerrie',
        'last_name' => 'Pate',
        'title' => 'HR Mgr',
        'clearinghouse_role' => 'Employer',
        'company' => 'Freightful',
        'street_address' => '1719 Tavern Place',
        'city' => 'Lakewood',
        'us_state' => 'CO',
        'postal_zip_code' => '80227',
        'phone' => '3039868459',
        'country' => 'US',
        'group_account' => true,
        'number_of_users' => 3,
      ),
      array(
        'name' => 'test_hd',
        'pass' => $pass,
        'mail' => 'dhoward@freightful.com',
        'first_name' => 'Daniel',
        'last_name' => 'Howard',
        'title' => 'HR Specialist',
        'clearinghouse_role' => 'Employer',
        'company' => 'Freightful',
        'street_address' => '1719 Tavern Place',
        'city' => 'Lakewood',
        'us_state' => 'CO',
        'postal_zip_code' => '80227',
        'phone' => '3039868460',
        'country' => 'US',
        'group_account' => false,
        'number_of_users' => 0,
      ),
      array(
        'name' => 'test_we',
        'pass' => $pass,
        'mail' => 'ewright@freightful.com',
        'first_name' => 'Ellen',
        'last_name' => 'Wright',
        'title' => 'Ops Mgr',
        'clearinghouse_role' => 'Employer',
        'company' => 'Freightful',
        'street_address' => '1719 Tavern Place',
        'city' => 'Phoenix',
        'us_state' => 'AZ',
        'postal_zip_code' => '85034',
        'phone' => '6233409956',
        'country' => 'US',
        'group_account' => false,
        'number_of_users' => 0,
      ),
      array(
        'name' => 'test_dm',
        'pass' => $pass,
        'mail' => 'dmalcolm@hotmail.com',
        'first_name' => 'David',
        'last_name' => 'Malcolm',
        'title' => 'Driver',
        'clearinghouse_role' => 'CDL Driver',
        'company' => 'FAST',
        'street_address' => '1688 Scenic Way',
        'city' => 'Lincoln',
        'us_state' => 'IL',
        'postal_zip_code' => '62656',
        'phone' => '2177371444',
        'country' => 'US',
        'group_account' => false,
        'number_of_users' => 1,
      ),
      array(
        'name' => 'test_ca',
        'pass' => $pass,
        'mail' => 'calbert@mednow.com',
        'first_name' => 'Cheryl',
        'last_name' => 'Albert',
        'title' => 'Medical Director',
        'clearinghouse_role' => 'Medical Review Officer',
        'company' => 'MedNow',
        'street_address' => '4387 Juniper Drive',
        'city' => 'Caro',
        'us_state' => 'MI',
        'postal_zip_code' => '48723',
        'phone' => '9898277629',
        'country' => 'US',
        'group_account' => true,
        'number_of_users' => 3,
      ),
      array(
        'name' => 'test_bg',
        'pass' => $pass,
        'mail' => 'gbass@mednow.com',
        'first_name' => 'Grtchen',
        'last_name' => 'Bass',
        'title' => 'Med Tech',
        'clearinghouse_role' => 'Medical Review Officer Assistant',
        'company' => 'MedNow',
        'street_address' => '4387 Juniper Drive',
        'city' => 'Caro',
        'us_state' => 'MI',
        'postal_zip_code' => '48723',
        'phone' => '9898277629',
        'country' => 'US',
        'group_account' => false,
        'number_of_users' => 0,
      ),
      array(
        'name' => 'test_fk',
        'pass' => $pass,
        'mail' => 'fkash@mednow.com',
        'first_name' => 'Frank',
        'last_name' => 'Kash',
        'title' => 'Med Tech',
        'clearinghouse_role' => 'Medical Review Officer Assistant',
        'company' => 'MedNow',
        'street_address' => '611 Swik Hill St.',
        'city' => 'Medtairie',
        'us_state' => 'LA',
        'postal_zip_code' => '70001',
        'phone' => '98982776293',
        'country' => 'US',
        'group_account' => false,
        'number_of_users' => 0,
      ),
      array(
        'name' => 'test_dg',
        'pass' => $pass,
        'mail' => 'renosap@aol.com',
        'first_name' => 'Debra',
        'last_name' => 'Garner',
        'title' => 'LCSW, SAP',
        'clearinghouse_role' => 'Substance Abuse Professional',
        'company' => '',
        'street_address' => '4199 Wescam Court',
        'city' => 'Reno',
        'us_state' => 'NV',
        'postal_zip_code' => '89502',
        'phone' => '7758616205',
        'country' => 'US',
        'group_account' => false,
        'number_of_users' => 0,
      ),
      array(
        'name' => 'test_rf',
        'pass' => $pass,
        'mail' => 'rfairbank@comppro.biz',
        'first_name' => 'Richard',
        'last_name' => 'Fairbank',
        'title' => 'CEO',
        'clearinghouse_role' => 'C/TPA',
        'company' => 'ComPro',
        'street_address' => '1152 Lakeland Park Drive',
        'city' => 'Conyers',
        'us_state' => 'GA',
        'postal_zip_code' => '30207',
        'phone' => '7706021335',
        'country' => 'US',
        'group_account' => true,
        'number_of_users' => 2,
      ),
      array(
        'name' => 'test_np',
        'pass' => $pass,
        'mail' => 'npickering@comppro.biz',
        'first_name' => 'Nina',
        'last_name' => 'Pickering',
        'title' => 'Analyst',
        'clearinghouse_role' => 'C/TPA',
        'company' => 'ComPro',
        'street_address' => '1152 Lakeland Park Drive',
        'city' => 'Conyers',
        'us_state' => 'GA',
        'postal_zip_code' => '30208',
        'phone' => '7706021335',
        'country' => 'US',
        'group_account' => true,
        'number_of_users' => 0,
      )
    );

    foreach ($users as $userInfo) {
      $account = $this->createUser($userInfo);
      if ($account) {
        $this->logger()->success(dt("User ") . $account->getUsername() . " has been created.");
//        $this->addToGroupUsertoGroup($account);
      } else {
        $this->logger()->error(dt("There has been an issue while creating a new user."));
      }
    }

  }

  public function createUser($userInfo) {
    $user = User::create([
      'name' => $userInfo['name'] . '01',
      'pass' => $userInfo['pass'],
      'mail' => $userInfo['mail'],
      'status' => 1,
      'roles' => array('authenticated'),
    ]);
    $user->set('field_first_name', ['value' => $userInfo['first_name']]);
    $user->set('field_last_name', ['value' => $userInfo['last_name']]);
    $user->set('field_title', ['value' => $userInfo['title']]);
    $user->set('field_company', ['value' => $userInfo['company']]);
    $user->set('field_clearinghouse_role', ['value' => $userInfo['clearinghouse_role']]);
    $user->set('field_street_address', ['value' => $userInfo['street_address']]);
    $user->set('field_city', ['value' => $userInfo['city']]);
    $user->set('field_us_state', ['value' => $userInfo['us_state']]);
    $user->set('field_postal_zip_code', ['value' => $userInfo['postal_zip_code']]);
    $user->set('field_country', ['value' => $userInfo['country']]);
    $user->set('field_telephone_number', ['value' => $userInfo['phone']]);
    $user->set('field_group_account', ['value' => $userInfo['group_account']]);
    $user->set('field_number_of_users', ['value' => $userInfo['number_of_users']]);
    $result = $user->save();
    if ($result) {
      $account = User::load($user->id());
      return $account;
    }
    return false;
  }

  private function configTheFirstUser() {
    // Add user 1 the information.
    $user = User::load(1);
    $user->set('field_first_name', ['value' => 'Quan']);
    $user->set('field_last_name', ['value' => 'Ngo']);
    $user->set('field_title', ['value' => 'Developer']);
    $user->set('field_company', ['value' => 'Windwalker Group']);
    $user->set('field_group_account', ['value' => true]);
    $user->set('field_number_of_users', ['value' => 5]);
    $this->setValuesToEntity(
      array(
        'field_clearinghouse_role' => 'Developer',
        'field_street_address' => '1945 Old Gallows Rd',
        'field_city' => 'Tysons Corner',
        'field_postal_zip_code' => '22102',
        'field_us_state' => 'VA',
      ),
      $user
    );
    $user->save();

    $group = Group::create([
        'type' => 'organization',
        'label' => 'Windwalker Group',
        'uid' => $user->id()
      ]
    );
    $group->enforceIsNew();
    $group->save();
    $group->addContent($user, 'group_membership', array('group_roles' => array('organization-admin')));
    $this->logger()->success(dt("User ") . $user->getUsername() . " has been added to {$group->label()}.");
    // Commentted out. Causes Error: The "" plugin does not exist.
//    $this->addToGroupUsertoGroup($user, 'Learning Path');
  }

  private function setValuesToEntity($values, $entity) {
    foreach ($values as $field => $value) {
      $entity->set($field, ['value' => $value]);
    }
  }

  private function addToGroupUsertoGroup($account, $groupTypeLabel) {
    /** @var \Drupal\group\Entity\Group[] $groups  */
    $groups = Group::loadMultiple();
      /**
       * @var  $gid
       * @var \Drupal\group\Entity\Group $group
       */
      foreach ($groups as $gid => $group) {
        if($group->getGroupType()->label() == $groupTypeLabel){
          $group->addContent($account, 'group_membership', array('group_roles' => array('learning_path-student')));
          $this->logger()->success(dt("User ") . $account->getUsername() . " has been added to {$group->label()}.");
        }
      }
  }

  /**
   * Create the Clearinghouse SCORM Course.
   *
   * @usage ch_nav:createCourse foo
   *   Usage description
   *
   * @command ch_nav:createCourse
   * @aliases chnavcc
   */
  public function createCourse() {
    $regProcessZipURL = $path = drupal_get_path('module', 'ch_nav') . '/assets/employee-health-scorm2004_v4.zip';
    $this->createLearningPathScorm('Registration Process', $regProcessZipURL);
    $this->createLearningPathScorm('Queries', $regProcessZipURL);
  }

  private function createLearningPathScorm($title, $zipUrl) {
    $group = wind_lms_create_group_learning_path($title);
    $module = wind_lms_create_module($title . ' Module');

    // Create the added item as an LP content.
    $new_content = \Drupal\opigno_group_manager\Entity\OpignoGroupManagedContent::createWithValues(
      $group->id(),
      'ContentTypeModule',
      $module->id(),
      0,
      1
    );
    $new_content->save();
    $group->addContent($module, 'opigno_module_group');

    $file = wind_lms_setFileRecord($zipUrl);
    $activity = wind_lms_createScormActivity($title . ' Activity', $file->id());

    /** @var \Drupal\opigno_module\Controller\OpignoModuleController $opigno_module_controller */
    $opigno_module_controller = \Drupal::service('opigno_module.opigno_module');
    $save_acitivities = $opigno_module_controller->activitiesToModule([$activity], $module);

    if (!$save_acitivities) {
      // Todo: Create error watchdog.
    } else {
      $this->logger()->success(dt('Created a course successfully.'));
    }
  }

  /**
   * Command description here.
   *
   * @param $arg1
   *   Argument description.
   * @param array $options
   *   An associative array of options whose values come from cli, aliases, config, etc.
   * @option option-name
   *   Description
   * @usage ch_nav-commandName foo
   *   Usage description
   *
   * @command ch_nav:commandName
   * @aliases foo
   */
  public function commandName($arg1, $options = ['option-name' => 'default']) {
    $this->logger()->success(dt('Achievement unlocked.'));
  }

  /**
   * An example of the table output format.
   *
   * @param array $options An associative array of options whose values come from cli, aliases, config, etc.
   *
   * @field-labels
   *   group: Group
   *   token: Token
   *   name: Name
   * @default-fields group,token,name
   *
   * @command ch_nav:token
   * @aliases token
   *
   * @filter-default-field name
   * @return \Consolidation\OutputFormatters\StructuredData\RowsOfFields
   */
  public function token($options = ['format' => 'table']) {
    $all = \Drupal::token()->getInfo();
    foreach ($all['tokens'] as $group => $tokens) {
      foreach ($tokens as $key => $token) {
        $rows[] = [
          'group' => $group,
          'token' => $key,
          'name' => $token['name'],
        ];
      }
    }
    return new RowsOfFields($rows);
  }
}
