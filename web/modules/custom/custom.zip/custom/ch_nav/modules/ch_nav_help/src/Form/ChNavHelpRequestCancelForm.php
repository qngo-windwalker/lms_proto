<?php

namespace Drupal\ch_nav_help\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\Core\Access\AccessResult;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;

class ChNavHelpRequestCancelForm extends FormBase{

  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;
  private $user;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_help_request_cancel_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL, $jira_request_id = NULL) {
    $this->group = $group;
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : 'internal:/';
    $form['#tree'] = TRUE;
    $form['jira_key'] = array(
      '#type' => 'value',
      '#value' => $jira_request_id

    );
    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Cancel Request',
      '#attributes' => array(
        'class' => ['btn', 'btn-danger']
      )
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $jirKey = $form_state->getValue('jira_key');
    $jiraRestWrapperService = new WindJiraWrapperService();
    $data = (object) [
      'id' => '901',
      'additionalComment' => [
        'body' => 'Client canceled request'
      ]
    ];
    $response = $jiraRestWrapperService->getServiceDeskService()->updateStatus($jirKey, $data);

    $messenger = \Drupal::messenger();
    // Cancel status return null is a false positive
    if ($response === null) {
      $messenger->addMessage(t('Request %jira_key cancelled successfully.', ['%jira_key' => $jirKey]), $messenger::TYPE_STATUS);
    } else {
      $messenger->addMessage(t('There was an error. Please try again.', []), $messenger::TYPE_ERROR);
    }

    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUri('internal:' . $destination));
    } else {
      $form_state->setRedirect('<front>');
    }
  }

  public function getTitle(Group $group, $jira_request_id) {
    return $this->t('Are you sure you want to cancel this request?', []);
  }

  public function access( Group $group, $jira_request_id) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }
}
