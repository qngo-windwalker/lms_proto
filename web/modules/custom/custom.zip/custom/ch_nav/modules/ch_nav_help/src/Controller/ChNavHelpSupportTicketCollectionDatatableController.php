<?php

namespace Drupal\ch_nav_help\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Component\Utility\Html;
use Drupal\Core\Controller\ControllerBase;
use Drupal\group\Entity\Group;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Render\Markup;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;

class ChNavHelpSupportTicketCollectionDatatableController extends ControllerBase{
  public function getContent(Group $group) {
    $collection = [];
    $schemaAndHost = \Drupal::request()->getSchemeAndHttpHost();
    $ourGroupURL = $schemaAndHost . '/org/' . $group->id();
    $serviceDeskId = null;
    if ($group->hasField('field_service_desk_org_id')) {
      $serviceDeskId = $group->get('field_service_desk_org_id')->getString();
    }
    $configFactory = \Drupal::configFactory();
    $jiraRestWrapperService = new WindJiraWrapperService($configFactory);
//    $query_parameters= http_build_query(array_filter( ['ORGANIZATION' => array(3)]));
//    $response = $jiraRestWrapperService->getServiceDeskService()->get('request/?' . $query_parameters);
    $response = $jiraRestWrapperService->getServiceDeskService()->get('request');
    if ($response) {
      foreach ($response->values as $std) {
        $jiraOrgId = null;
        $summary = '';
        $description = '';
        $originatedLink = '';
        foreach ($std->requestFieldValues as $requestFieldValue){
          // Clearinghouse Organization Id
          if ($requestFieldValue->fieldId == 'customfield_10113') {
            $jiraOrgId = isset($requestFieldValue->value) ? $requestFieldValue->value : null;
          }
          if ($requestFieldValue->fieldId == 'summary') {
            $summary = Html::escape($requestFieldValue->value);
          }
          if ($requestFieldValue->fieldId == 'description') {
            $description = Xss::filter($requestFieldValue->value);
          }

          if ($requestFieldValue->fieldId == 'customfield_10114') {
            $originatedLink = Xss::filter($requestFieldValue->value);
          }
        }
        // Filter out to only applicable Jira Service Desk organization Id.
        // Todo: Optimize using REST API query
        if($ourGroupURL != $originatedLink){
          continue;
        }

        $collection[] = [
          'issueId' => $this->genTicketLink($std->issueId, $group->id(), $std->issueId),
          'issueKey' => $std->issueKey,
          'summary' => $summary,
          'createdDate' => $std->createdDate->friendly,
          'currentStatus' => $std->currentStatus->status,
          'currentStatusDate' => $std->currentStatus->statusDate->friendly,
          'description' => $description,
          'customfield_10113' => $jiraOrgId,
          'jiraOrgId' => $jiraOrgId,
          'operations' => $this->getTicketOperation($group->id(), $std->issueId, $std->currentStatus->status),
        ];
      }
    }
    return new JsonResponse(['data' => $collection]);
  }

  private function formatTime($timestamp) {
    if ($timestamp) {
      return date('m-d-Y', $timestamp);
    } else {
      // If the $timestamp is 0
      return 'Never';
    }
  }

  private function genTicketLink($label, $groupId, $ticketId){
    $linkURL = Url::fromUserInput(
      "/org/{$groupId}/support-ticket/{$ticketId}",
      array(
        'attributes' => array('class' => '')
      )
    );
    $renderedAnchorContent = render($label);
    return Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $linkURL)->toString();
  }


  private function currentUserHasOrgPermission($user, $group_organization, $string) {
    // Note! Current user can be outside of current group_organization such as admin.
    if(wind_does_user_has_sudo($user)){
      return true;
    };
    $roles = wind_lms_get_user_group_roles($user, $group_organization);
    if (isset($roles['organization-admin'])) {
      return true;
    }

    return false;
  }

  private function getInviteeOperation($invitee, $group) {
    if(!$this->currentUserHasOrgPermission(\Drupal::currentUser(), $group, 'edit user')){
      return 'N/A';
    };
    $resendInviteURL = Url::fromUserInput(
      "/org/{$group->id()}/invite/{$invitee->id()}/resend",
      array(
        'query' => ['destination' => "/org/{$group->id()}"],
        'attributes' => array('class' => '')
      )
    );
    $withdrawInviteURL = Url::fromUserInput(
      "/org/{$group->id()}/invite/{$invitee->id()}/withdraw",
      array(
        'query' => ['destination' => "/org/{$group->id()}"],
        'attributes' => array('class' => 'card-link text-danger')
      )
    );
    $linkContent = '<i class="fas fa-pen"></i> Resend';
    $renderedAnchorContent = render($linkContent);
    $removeLinkContent = '<i class="fas fa-minus-circle"></i> Withdraw';
    $output = Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $resendInviteURL)->toString();
    $output .= '<br />' . Link::fromTextAndUrl(Markup::create(render($removeLinkContent)), $withdrawInviteURL)->toString();
    return $output;
  }

  /**
   * Check the access to this form.
   */
  public function access(Group $group) {
    $user = \Drupal::currentUser();
    if (wind_does_user_has_sudo($user)){
      return AccessResult::allowed();
    }

    if($group->getMember(\Drupal::currentUser())){
      return AccessResult::allowed();
    }
    return AccessResult::neutral();
  }

  private function getTicketOperation($groupId, $issueId, $status) {
    $path = "/org/{$groupId}/support-ticket";
    $resolveLink = '';
    $cancelLink = '';
    if ($status != 'Closed' && $status != 'Canceled' && $status != 'Resolved') {
      $cancelUrl = Url::fromUserInput(
        $path . "/{$issueId}/cancel",
        array(
          'query' => ['destination' => $path],
          'attributes' => array('class' => 'text-danger')
        )
      );
      $resolvelUrl = Url::fromUserInput(
        $path . "/{$issueId}/resolve",
        array(
          'query' => ['destination' => $path],
          'attributes' => array('class' => '')
        )
      );

      $cancelLink = '<br/>' . $this->link('Cancel', $cancelUrl);
      $resolveLink = '<br/>' . $this->link('Resolve', $resolvelUrl);
    }
    $viewLink = '<br/>' . $this->genTicketLink('View', $groupId, $issueId);

    return "<p>{$viewLink} {$resolveLink} {$cancelLink} </p>";
  }
  private function link($label, $url) {
    $renderedAnchorContent = render($label);
    return Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
  }
}
