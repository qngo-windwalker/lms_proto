<?php

namespace Drupal\ch_nav_help\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\Core\Access\AccessResult;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;

class ChNavHelpRequestResolveForm extends FormBase{

  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_help_request_resolve_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Group $group = NULL, $jira_request_id = NULL) {
    $this->group = $group;
    $destination = \Drupal::request()->query->get('destination');
    $uri = $destination ? 'internal:' . $destination : 'internal:/';
    $form['#tree'] = TRUE;
    $form['jira_key'] = array(
      '#type' => 'value',
      '#value' => $jira_request_id

    );
    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromUri($uri),
      '#attributes' => array(
        'class' => ['btn', 'btn-secondary', 'mr-1']
      )
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Resolve',
      '#attributes' => array(
        'class' => ['btn', 'btn-success']
      )
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $jirKey = $form_state->getValue('jira_key');
    $jiraRestWrapperService = new WindJiraWrapperService();
    // transition id can be found at clearinghousenavigator.atlassian.net/rest/api/2/issue/{$jirKey}/transitions?expand=transitions.fields
    // tried: 941

    $data = (object) [
      'id' => '761',
//      'additionalComment' => [
//        'body' => 'Client resolved request'
//      ]
    ];
    $response = $jiraRestWrapperService->getServiceDeskService()->updateStatus($jirKey, $data);

    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUri('internal:' . $destination));
    } else {
      $form_state->setRedirect('<front>');
    }
    $messenger = \Drupal::messenger();
    if ($response === false) {
      $messenger->addMessage(t('There was an error. Please try again.', [
        '%jira_key' => $jirKey,
      ]), $messenger::TYPE_ERROR);

    }
    // Resolve status return null is a false positive
    if ($response === null) {
      $messenger->addMessage(t('Request %jira_key resolved successfully.', [
        '%jira_key' => $jirKey,
      ]), $messenger::TYPE_STATUS);
    }
  }

  public function getTitle(Group $group, $jira_request_id) {
    return $this->t('Are you sure you want to resolve this request?', []);
  }

  public function access( Group $group, $jira_request_id) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }
}
