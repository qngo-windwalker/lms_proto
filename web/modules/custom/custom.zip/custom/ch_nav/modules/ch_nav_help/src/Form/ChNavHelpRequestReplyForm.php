<?php

namespace Drupal\ch_nav_help\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Url;
use Drupal\Core\Access\AccessResult;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;

class ChNavHelpRequestReplyForm extends FormBase {
  /**
   * @var \Drupal\group\Entity\Group $group
   */
  private $group;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ch_nav_help_atlassian_request_reply';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $key = null) {
    $form['#tree'] = TRUE;
    $form['jira_key'] = [
      '#type' => 'value',
      '#value' => $key,
    ];
    $form['reply'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Reply'),
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Submit Ticket',
      '#attributes' => array(
        'class' => ['btn', 'btn-primary']
      )
    ];
    return $form;
  }

  /**
   * @see \Drupal\image\Controller\QuickEditImageController->upload() to see how to implement Ajax.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $key = $form_state->getValue('jira_key');
    $jiraRestWrapperService = new WindJiraWrapperService();
    $data = new \stdClass();
    $data->public = true;
    $data->body = $form_state->getValue('reply');
    $response = $jiraRestWrapperService->getServiceDeskService()->createComment($key, $data);
    $messenger = \Drupal::messenger();
    if ($response) {
//      $messenger->addMessage(t('Your reply has been submitted.', []), $messenger::TYPE_STATUS);
    } else {
      $messenger->addMessage(t('There was an error. Please try again.', []), $messenger::TYPE_ERROR);
    }

    $destination = \Drupal::request()->query->get('destination');
    if ($destination) {
      $form_state->setRedirectUrl(Url::fromUserInput($destination));
    }
  }

  public function access(Group $group) {
    $currentUser = \Drupal::currentUser();
    if (wind_does_user_has_sudo($currentUser)){
      return AccessResult::allowed();
    }

    $membership = $group->getMember($currentUser);
    if(!$membership){
      return AccessResult::forbidden();
    }

    // Check if the current user has the right role or permissions.
    $roles = wind_lms_get_user_group_roles($currentUser, $group);
    foreach ($roles as $role) {
      if ($role->label() == 'Admin') {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

  public function getTitle(Group $group) {
    return $this->t('Add Licenses for %label', [
      '%label' => $group->label(),
    ]);
  }

}
