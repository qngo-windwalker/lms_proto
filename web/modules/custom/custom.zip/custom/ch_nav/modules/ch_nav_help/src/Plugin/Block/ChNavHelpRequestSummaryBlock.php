<?php

namespace Drupal\ch_nav_help\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\group\Entity\Group;
use Drupal\Core\Render\Markup;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;
use Drupal\Component\Utility\Xss;
use Drupal\Component\Utility\Html;

/**
 * Provides a 'WindIntroBlock' block.
 *
 * @Block(
 *  id = "ch_nav_help_request_summary_block",
 *  admin_label = @Translation("Request"),
 * )
 */
class ChNavHelpRequestSummaryBlock extends BlockBase {

  public function __construct(array $configuration, $plugin_id, $plugin_definition) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $currentUser = \Drupal::currentUser();
    $org = ch_nav_get_user_group_organization($currentUser);
    $markup = $this->genCreateRequestLink($org->id()) . $this->genSupportRequestLink($org->id()) ;
    $title = $this->getConfigValue('label', 'Open Help Request');
    $build['#theme'] = 'wind_bootstrap_block_card';
    $build['#label'] = $title;
    $build['#content'] = $this->getBlockContent($org) . $markup;
    return $build;
  }

  /**
   * {@inheritdoc}
   */
//  protected function blockAccess(AccountInterface $account) {
//    /** @var \Drupal\Core\Entity\EntityInterface $entity */
//    $entity = $this->getContextValue('entity');
//    // Make sure we have access to the entity.
//    $access = $entity->access('view', $account, TRUE);
//    if ($access->isAllowed()) {
//      // Check that the entity in question has this field.
//      if ($entity instanceof FieldableEntityInterface && $entity->hasField($this->fieldName)) {
//        // Check field access.
//        $field_access = $this->entityTypeManager
//          ->getAccessControlHandler($this->entityTypeId)
//          ->fieldAccess('view', $this->getFieldDefinition(), $account);
//
//        if ($field_access) {
//          // Build a renderable array for the field.
//          $build = $entity->get($this->fieldName)->view($this->configuration['formatter']);
//          // If there are actual renderable children, grant access.
//          if (Element::children($build)) {
//            return AccessResult::allowed();
//          }
//        }
//      }
//      // Entity doesn't have this field, so access is denied.
//      return AccessResult::forbidden();
//    }
//    // If we don't have access to the entity, return the forbidden result.
//    return $access;
//  }

  /**
   * {@inheritdoc}
   */
//  public function access(AccountInterface $account, $return_as_object = FALSE) {
//    return $account->hasPermission('administer site configuration');
//  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $formState) {
    $form = parent::blockForm($form, $formState);
    $form['body'] = array(
      '#type' => 'textarea',
      '#title' => t('Body'),
      '#default_value' => $this->getConfigValue('body', $this->defaultBodyContent)
    );

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $formState) {
    $this->configuration['body'] = $formState->getValue('body');

    return $form;
  }

  public function getCacheMaxAge() {
    return 0;
  }

  private function getConfigValue($key, $defaultValue) {
    return (isset($this->configuration[$key]) && $this->configuration[$key]) ? $this->configuration[$key] : $defaultValue;
  }

  private function getBlockContent(Group $group) {
    $header = [
      array('data' => 'Status', 'class' => 'user-full-name-header'),
      array('data' => 'Subject', 'class' => 'user-email-header'),
      array('data' => 'Last Updated', 'class' => 'user-group-role-header'),
    ];
    $renderable = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $this->getTableRows($group),
      '#empty' => t('There are no data.'),
      '#attributes' => array(
        'id' => 'course-tbl',
        'class' => array('table' ,'table-wind-theme-strip')
      ),
    ];
    return \Drupal::service('renderer')->render($renderable);

  }

  private function getTableRows(Group $group) {
    $configFactory = \Drupal::configFactory();
    $jiraRestWrapperService = new WindJiraWrapperService($configFactory);
//    $query_parameters= http_build_query(array_filter( ['ORGANIZATION' => array(3)]));
//    $response = $jiraRestWrapperService->getServiceDeskService()->get('request/?' . $query_parameters);
    $response = $jiraRestWrapperService->getServiceDeskService()->get('request');
    if (!$response) {
      return [];
    }

    $serviceDeskId = null;
    if ($group->hasField('field_service_desk_org_id')) {
      $serviceDeskId = $group->get('field_service_desk_org_id')->getString();
    }
    $rows = array();
    foreach ($response->values as $std) {
      $jiraOrgId = null;
      $summary = '';
      $description = '';
      $status = $std->currentStatus->status;
      foreach ($std->requestFieldValues as $requestFieldValue){
        // Clearinghouse Organization Id
        if ($requestFieldValue->fieldId == 'customfield_10113') {
          $jiraOrgId =  isset($requestFieldValue->value) ? $requestFieldValue->value : null;
        }
        if ($requestFieldValue->fieldId == 'summary') {
          $summary = Html::escape($requestFieldValue->value);
        }
        if ($requestFieldValue->fieldId == 'description') {
          $description =  Xss::filter($requestFieldValue->value);
        }
      }
      // Filter out to only applicable Jira Service Desk organization Id.
      // Todo: Optimize using REST API query
      if($jiraOrgId != $serviceDeskId){
        continue;
      }

      if ($status == 'Closed' || $status == 'Canceled' || $status == 'Resolved') {
        continue;
      }

      $rows[] = [
        $summary,
        $std->currentStatus->status,
        $std->currentStatus->statusDate->friendly,
      ];
    }

    return $rows;
  }

  private function genCreateRequestLink($gid) {
    $url = Url::fromUserInput(
      '/help',
      array('attributes' => array('class' => 'card-link'))
    );
    $linkContent = '<i class="fas fa-plus-circle"></i> Create Request';
    $renderedAnchorContent = render($linkContent);
    return Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
  }

  private function genSupportRequestLink($gid) {
    $url = Url::fromUserInput(
      "/org/{$gid}/support-ticket",
      array('attributes' => array('class' => 'card-link'))
    );
    $linkContent = '<i class="fas fa-eye"></i> View All Support Requests';
    $renderedAnchorContent = render($linkContent);
    return Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
  }
}
