<?php

namespace Drupal\ch_nav_help\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Drupal\group\Entity\Group;
use Drupal\Core\Render\Markup;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Access\AccessResult;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;

class ChNavHelpSupportTicketController extends ControllerBase{
  public function getContent(Group $group, $jira_request_id) {
    $jiraRestWrapperService = new WindJiraWrapperService();
    $response = $jiraRestWrapperService->getServiceDeskService()->get('request/' . $jira_request_id);
    $output = '';
    $output .= $this->genTableInfo($response);
    $jiraOrgId = null;
    $summary = '';
    $description = '';
    foreach ($response->requestFieldValues as $requestFieldValue){
      // Clearinghouse Organization Id
      if ($requestFieldValue->fieldId == 'customfield_10113') {
        $jiraOrgId = isset($requestFieldValue->value) ? $requestFieldValue->value : '';
      }
      if ($requestFieldValue->fieldId == 'summary') {
        $summary =  $requestFieldValue->value;
      }
      if ($requestFieldValue->fieldId == 'description') {
        $description =  $requestFieldValue->value;
      }
    }
    $output .= '<div><h5>Description</h5><p>' . $description . '</p></div>';
    $output .= '<p>' . $this->getComment($jira_request_id) . '</p>';
    return [
      'content' => [
        '#markup' => $output,
      ],
      'form' =>\Drupal::formBuilder()->getForm(\Drupal\ch_nav_help\Form\ChNavHelpRequestReplyForm::class, $jira_request_id),
      'buttons' => [
        '#markup' => '<div class="pt-3">' .  $this->getActionButtons() . '</div>'
      ]
    ];
  }

  private function getLicensesSection($totalLicenses, $activeUserCount, $group_organization) {
    $url = Url::fromUserInput(
      "/org/{$group_organization->id()}/addlicenses",
      array(
        'query' => [
          'destination' => Url::fromRoute('<current>')->toString(),
        ],
        'attributes' => array('class' => '')
      )
    );
    $linkContent = '<i class="fas fa-plus-circle"></i> Add Licenses';
    $renderedAnchorContent = render($linkContent);
    $addLicensesLink = Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
    $percent = $activeUserCount / $totalLicenses;
    $output = '<div class="col-12-md mb-5">';
    $output .= '<h3>Licenses</h3>';
    $output .= '<div class="progress mb-4">';
    $output .= '<div class="progress-bar" data-width="' . $percent . '" aria-valuemax="100"></div>';
    $output .= '</div>';
    $output .= '  <div class="row">';
    $output .= '    <div class="col-md-4">Total Licenses: '. $totalLicenses . ' </div><div class="col-md-4">Used Licences: ' . $activeUserCount . ' </div><div class="col-md-4">' . $addLicensesLink . '</div>';
    $output .= '  </div>';
    $output .= '</div>';
    return $output;
  }

  private function getDataTableRenderable($tableElemntId, $datatableURL) {
    $header = [
      array('data' => 'Ticket ID', 'class' => 'node-first-name-header'),
      array('data' => 'Type', 'class' => 'node-last-name-header'),
      array('data' => 'Status', 'class' => 'node-email-header'),
      array('data' => 'Created On', 'class' => 'node-enrollment-header'),
      array('data' => 'Last Updated', 'class' => 'node-last-login-header'),
      array('data' => 'Operations', 'class' => 'node-operations-header'),
    ];

    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => array(),
      '#empty' => t('There are no data.'),
      '#attributes' => array(
        'id' => $tableElemntId,
        'class' => array('table' ,'table-wind-theme-strip')
      ),
      '#attached' => array(
        'library' => array(
          'ch_nav/course_org'
        ),
        'drupalSettings' => array(
          'ch_nav' => array(
            'datatableURL' => $datatableURL,
            'datatableElementId' => '#' . $tableElemntId
          )
        )
      )
    ];
  }

  public function getTitle(Group $group, $jira_request_id){
    $jiraRestWrapperService = new WindJiraWrapperService();
    $response = $jiraRestWrapperService->getServiceDeskService()->get('request/' . $jira_request_id);
    $summary = $jira_request_id;
    foreach ($response->requestFieldValues as $requestFieldValue){
      if ($requestFieldValue->fieldId == 'summary') {
        $summary = Xss::filter($requestFieldValue->value);
      }
    }
    return $summary;
  }

  /**
   * Check the access to this form.
   */
  public function access(Group $group, $jira_request_id) {
    $user = \Drupal::currentUser();
    if (wind_does_user_has_sudo($user)){
      return AccessResult::allowed();
    }
    if($group->getMember($user)){
      return AccessResult::allowed();
    }
    return AccessResult::neutral();
  }

  private function genTableInfo($response) {
    $header = [
      array('data' => 'ID', 'class' => 'jira-id-header'),
      array('data' => 'Type', 'class' => 'jira-type-header'),
      array('data' => 'Status', 'class' => 'jira-status-header'),
      array('data' => 'Created On', 'class' => 'jira-created-on-header'),
      array('data' => 'Reported By', 'class' => 'jira-reported-by-header'),
    ];

    $renderable = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => array(
        [
          $response->issueId,
          $response->issueKey,
          $response->currentStatus->status,
          $response->createdDate->friendly,
          $response->reporter->name . ' : ' . $response->reporter->emailAddress,
        ]
      ),
      '#empty' => t('There are no data.'),
      '#attributes' => array(
        'id' => 'ticket-info-tbl',
        'class' => array('table' ,'table-wind-theme-strip')
      ),
    ];

    return render($renderable);
  }

  private function getActionButtons() {
    $currentPath = \Drupal::service('path.current')->getPath();
    $cancelUrl = Url::fromUserInput(
      $currentPath . "/cancel",
      array(
        'query' => ['destination' => $currentPath],
        'attributes' => array('class' => 'btn btn-info')
      )
    );
    $resolvelUrl = Url::fromUserInput(
      $currentPath . "/resolve",
      array(
        'query' => ['destination' => $currentPath],
        'attributes' => array('class' => 'btn btn-info')
      )
    );

    $cancelLink = $this->link('Cancel Request', $cancelUrl);
    $resolveLink = $this->link('Resolve', $resolvelUrl);
    return '<p>' . $cancelLink . ' ' . $resolveLink . '</p>';
  }

  private function link($label, $url) {
    $renderedAnchorContent = render($label);
    return Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
  }

  private function getComment($jira_request_id){
    $jiraRestWrapperService = new WindJiraWrapperService();
    $response = $jiraRestWrapperService->getServiceDeskService()->get('request/' . $jira_request_id . '/comment');
    if(!isset($response->values)){
      return '';
    }
    $output = '';
    foreach ($response->values as $value) {
      $output .= '<div class="comment-section row mb-2">';
      $output .= '<div class="comment-section col-md-1">';
      $output .= '<p><img width="42" src="' . $value->author->_links->avatarUrls->{'16x16'} . '" /> ' . '</p>';
      $output .= '</div>';
      $output .= '<div class="comment-section col-md-11">';
      $output .= '<p><strong>' . $value->author->displayName . '</strong> <small>' . $value->created->friendly . '</small></p>';
      $output .= '<p>' . $value->body . '</p>';
      $output .= '</div>';
      $output .= '</div>';
    }
    return '<h5 class="mb-3">Activity</h5>' . $output;
  }
}
