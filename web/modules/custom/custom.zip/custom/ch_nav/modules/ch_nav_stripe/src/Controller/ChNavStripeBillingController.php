<?php

namespace Drupal\ch_nav_stripe\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Controller\ControllerBase;
use Drupal\group\Entity\Group;
use Drupal\Core\Render\Markup;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Access\AccessResult;
use Drupal\wind_jira\JiraRest\WindJiraWrapperService;

class ChNavStripeBillingController extends ControllerBase{
  public function getContent(Group $group) {

    // Set your secret key: remember to change this to your live secret key in production
//    // See your keys here: https://dashboard.stripe.com/account/apikeys
//    \Stripe\Stripe::setApiKey('sk_test_EJ91aFtJ4U9RFE3BN1iNYGJo00WGPft1sv');
//////    \Stripe\Stripe::setApiKey('sk_test_4eC39HqLyjWDarjtT1zdp7dc');
////
////    $charge = \Stripe\Charge::create([
////      'amount' => 999,
////      'currency' => 'usd',
////      'source' => 'tok_visa',
////      'receipt_email' => 'jenny.rosen@example.com',
////    ]);
//
//    $plan = \Stripe\Plan::create([
//      'product' => 'prod_FhBdCGu3y1HCVY',
//      'nickname' => 'Basic Yearly Plan 1-10',
//      'interval' => 'year',
//      'currency' => 'usd',
//      // $25.00
//      'amount' => '2500'
//    ]);
//
//    $output = print_r($plan, true);
//    kint($output);
    return [
      'content' => [
        '#markup' => 'hello',
      ],
    ];
  }


  private function getDataTableRenderable($tableElemntId, $datatableURL) {
    $header = [
      array('data' => 'Invoice Number', 'class' => 'node-first-name-header'),
      array('data' => 'Type', 'class' => 'node-last-name-header'),
      array('data' => 'Status', 'class' => 'node-email-header'),
      array('data' => 'Created On', 'class' => 'node-enrollment-header'),
      array('data' => 'Last Updated', 'class' => 'node-last-login-header'),
      array('data' => 'Operations', 'class' => 'node-operations-header'),
    ];

    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => array(),
      '#empty' => t('There are no data.'),
      '#attributes' => array(
        'id' => $tableElemntId,
        'class' => array('table' ,'table-wind-theme-strip')
      ),
      '#attached' => array(
        'library' => array(
          'ch_nav/course_org'
        ),
        'drupalSettings' => array(
          'ch_nav' => array(
            'datatableURL' => $datatableURL,
            'datatableElementId' => '#' . $tableElemntId
          )
        )
      )
    ];
  }

  /**
   * Check the access to this form.
   */
  public function access(Group $group) {
    $user = \Drupal::currentUser();
    if (wind_does_user_has_sudo($user)){
      return AccessResult::allowed();
    }
    if($group->getMember($user)){
      return AccessResult::allowed();
    }
    return AccessResult::neutral();
  }


  private function getActionButtons() {
    $currentPath = \Drupal::service('path.current')->getPath();
    $cancelUrl = Url::fromUserInput(
      $currentPath . "/cancel",
      array(
        'query' => ['destination' => $currentPath],
        'attributes' => array('class' => 'btn btn-info')
      )
    );
    $resolvelUrl = Url::fromUserInput(
      $currentPath . "/resolve",
      array(
        'query' => ['destination' => $currentPath],
        'attributes' => array('class' => 'btn btn-info')
      )
    );

    $cancelLink = $this->link('Cancel Request', $cancelUrl);
    $resolveLink = $this->link('Resolve', $resolvelUrl);
    return '<p>' . $cancelLink . ' ' . $resolveLink . '</p>';
  }

  private function link($label, $url) {
    $renderedAnchorContent = render($label);
    return Link::fromTextAndUrl(Markup::create($renderedAnchorContent), $url)->toString();
  }

}
