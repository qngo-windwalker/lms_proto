<?php

namespace Drupal\wind\EventSubscriber;

use Drupal\Core\Config\ConfigImporterEvent;
use Drupal\Core\Config\ConfigImportValidateEventSubscriberBase;
use Drupal\Core\Config\ConfigManagerInterface;
use Drupal\Core\Config\Entity\ConfigEntityStorage;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Check moderation states are not being used before updating workflow config.
 */
class WindConfigImportSubscriber extends ConfigImportValidateEventSubscriberBase {

  /**
   * The config manager.
   *
   * @var \Drupal\Core\Config\ConfigManagerInterface
   */
  protected $configManager;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs the event subscriber.
   *
   * @param \Drupal\Core\Config\ConfigManagerInterface $config_manager
   *   The config manager
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(ConfigManagerInterface $config_manager, EntityTypeManagerInterface $entity_type_manager) {
    $this->configManager = $config_manager;
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public function onConfigImporterValidate(ConfigImporterEvent $event) {
    $config_importer = $event->getConfigImporter();
//    $validated = $config_importer->validate();
    $config_importer->getStorageComparer()->getSourceStorage()->listAll();

    foreach ($config_importer->getStorageComparer()->getSourceStorage()->listAll() as $name) {
      list($owner,) = explode('.', $name, 2);
    }

    foreach (['delete', 'create', 'update'] as $op) {
      $unprocessed_configurations = $event->getConfigImporter()->getUnprocessedConfiguration($op);

    }
  }


}
