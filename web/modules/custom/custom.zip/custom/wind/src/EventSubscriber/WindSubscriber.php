<?php
/**
 * event subscriber.
 */

namespace Drupal\wind\EventSubscriber;

// This is the interface we are going to implement.
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
// This class contains the event we want to subscribe to.
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\RouteCollection;
use Drupal\Core\Routing\RouteBuildEvent;
use Drupal\Core\Routing\RoutingEvents;

class WindSubscriber implements EventSubscriberInterface{

    /**
     * {@inheritdoc}
     */
    static function getSubscribedEvents() {
        $event[KernelEvents::REQUEST][] = array('onRequest');
        $events[RoutingEvents::ALTER][] = 'onAlterRoutes';
        return $event;
    }

    public function onRequest(GetResponseEvent $event) {
    }

    public function onAlterRoutes(RouteBuildEvent $event) {
        dsm($event);
        $collection = $event->getRouteCollection();
        $this->alterRoutes($collection);
    }

    protected function alterRoutes(RouteCollection $collection){
        dsm($collection);

    }

}