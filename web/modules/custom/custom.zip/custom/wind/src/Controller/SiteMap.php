<?php

namespace Drupal\wind\Controller;

use Drupal\Core\Controller\ControllerBase;

class SiteMap extends ControllerBase {

  public function content() {
    return [
      '#type' => 'markup',
      '#markup' => 'Site map coming soon..',
    ];
  }
}