<?php

namespace Drupal\wind\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;

class WindDatatableController {

  public function user_progress() {
    $collection = [];
    $query = \Drupal::entityQuery('user');
    $query->condition('status', 1)
      ->condition('roles', 'learner');
    $result = $query->execute();

    if ($result) {
      foreach ($result as $uid) {
        $user_account = user_load($uid);
        $account = \Drupal\user\Entity\User::load($uid);
        $first_name = $account->get('field_user_first_name')->isEmpty() ? '' : $user_account->get('field_user_first_name')->value;
        $last_name = $account->get('field_user_last_name')->isEmpty() ? '' : $user_account->get('field_user_last_name')->value;
        $progress = $this->getUserProgress($account);
        $collection[] = [$first_name, $last_name, 'progress' => $progress, 'userId' => $uid];
      }
    }

    return new JsonResponse(['data' => $collection]);
  }

  /**
   * Get user percentage of completion.
   * @param $user
   *
   * @return float
   */
  protected function getUserProgress($user) {
    $grp_membership_service = \Drupal::service('group.membership_loader');
    $grps = $grp_membership_service->loadByUser($user);
    foreach ($grps as $grp) {
      $group = $grp->getGroup();
      $uid = $user->id();
      $progress = opigno_learning_path_progress($group->id(), $uid);
      $progress = round(100 * $progress);
      return $progress;
    }
  }
}