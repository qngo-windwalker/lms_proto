<?php

namespace Drupal\wind\Controller;

class FAQPageController{

  public function content() {
    return array(
      '#type' => 'markup',
      '#markup' => 'FAQ coming soon.',
    );
  }
}