<?php

namespace Drupal\wind\Controller;

use Drupal\Core\Controller\ControllerBase;

class WindAccessDeniedPageController extends ControllerBase{

  public function getContent() {
    return array(
      '#type' => 'markup',
      '#markup' => ''
    );
  }
}
