<?php

namespace Drupal\wind\Controller;

use Drupal\block\Entity\Block;

/**
 * Controller for all the actions of the Learning Path manager app.
 */
class HomePageController {

  public function content(){

    $block = \Drupal\block\Entity\Block::load('seven_login');
    $block_content = \Drupal::entityTypeManager()->getViewBuilder('block')->view($block);

    return array(
      '#type' => 'markup',
      '#markup' => drupal_render($block_content),
      '#prefix' => '<div id="seven-login-wrapper"><div class="row"><div class="col-md-6">',
      '#suffix' => '</div></div></div>'
    );
  }
}