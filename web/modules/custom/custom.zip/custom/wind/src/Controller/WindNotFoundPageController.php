<?php

namespace Drupal\wind\Controller;

use Drupal\Core\Controller\ControllerBase;

class WindNotFoundPageController extends ControllerBase{

  public function getContent() {
    return array(
      '#type' => 'markup',
      '#markup' => 'The page page could not be found.'
    );
  }
}
