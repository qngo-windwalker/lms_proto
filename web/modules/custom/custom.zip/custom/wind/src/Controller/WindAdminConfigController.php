<?php

namespace Drupal\wind\Controller;

use Drupal\Core\Controller\ControllerBase;

class WindAdminConfigController extends ControllerBase{

  public function contactPage() {
    return [
      '#prefix' => '<div id="wind_configuration_page">',
      '#suffix' => '</div>',
      'form' => $this->formBuilder->getForm('\Drupal\wind\Form\WindAdminConfigForm'),
    ];
  }

  public function getEmailPage() {
    return [
      '#prefix' => '<div id="wind_configuration_page">',
      '#suffix' => '</div>',
//      'form' => $this->formBuilder->getForm('\Drupal\wind\Form\WindAdminConfigEmailForm'),
      'form' => $this->formBuilder->getFormId('wind_config_email'),
    ];
  }
}
