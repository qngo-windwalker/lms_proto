<?php

/**
 * Enable custom theme option in *.routing.yml. Example:
 *  options:
 *     _custom_theme: 'cn_theme'
 * See wind.services.yml for priority value.
 *
 * Giving credit:
 * @see https://webomelette.com/choose-your-theme-dynamically-drupal-8-theme-negotiation
 */

namespace Drupal\wind\Theme;

use Drupal\Core\Routing\RouteMatchInterface;
use Symfony\Component\Routing\Route;
use Drupal\Core\Theme\ThemeNegotiatorInterface;

class WindThemeNegotiator implements ThemeNegotiatorInterface{

  private $customTheme;
  /**
   * {@inheritdoc}
   */
  public function applies(RouteMatchInterface $route_match) {
    $route = $route_match->getRouteObject();
    if (!$route instanceof Route) {
      return FALSE;
    }
    $option = $route->getOption('_custom_theme');
    if ($option) {
      $this->customTheme = $option;
      return $option;
    }
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function determineActiveTheme(RouteMatchInterface $route_match) {
    return $this->customTheme;
  }
}
