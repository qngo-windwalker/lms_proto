<?php

namespace Drupal\wind;

class WindTwigExtension extends \Twig_Extension {

  /**
   * {@inheritdoc}
   */
  public function getPath($name, $parameters = [], $options = []) {
    $options['absolute'] = FALSE;
    return $this->urlGenerator->generateFromRoute($name, $parameters, $options);
  }
}
