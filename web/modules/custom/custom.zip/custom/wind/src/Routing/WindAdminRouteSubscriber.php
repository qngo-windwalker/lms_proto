<?php

namespace Drupal\wind\Routing;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Sets the _admin_route for specific group-related routes.
 */
class WindAdminRouteSubscriber extends RouteSubscriberBase {

    /**
     * The config factory.
     *
     * @var \Drupal\Core\Config\ConfigFactoryInterface
     */
    protected $configFactory;

    /**
     * Constructs a new GroupAdminRouteSubscriber.
     *
     * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
     *   The config factory.
     */
//    public function __construct(ConfigFactoryInterface $config_factory) {
//        $this->configFactory = $config_factory;
//    }

    /**
     * Todo: Currently not working. Find out why
     * {@inheritdoc}
     */
    protected function alterRoutes(RouteCollection $collection) {
        foreach ($collection->all() as $route) {
            //  group/1/item-form/ContentTypeModule/2
            if($collection->get('opigno_group_manager.manager.get_item_form') == $route){
                $route->setOption('_admin_route', TRUE);
            }

            if($collection->get('opigno_group_manager.manager.index') == $route){
                $route->setOption('_admin_route', TRUE);
//                $route->setOption('_custom_theme', 'platon');
            }

            // /group/1/inner-modules/
            // When editing a learning path group
            if($collection->get('opigno_learning_path.learning_path_modules') == $route){
                $route->setOption('_admin_route', TRUE);
            }

            // /module/2/item-form/opigno_scorm/?library=undefined
            // The iframe when adding a SCORM package
            if($collection->get('opigno_module.manager.get_item_form') == $route){
                $route->setOption('_admin_route', TRUE);
            }
        }
    }

}
