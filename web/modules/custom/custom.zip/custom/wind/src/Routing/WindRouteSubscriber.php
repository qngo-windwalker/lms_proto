<?php

namespace Drupal\wind\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;


/**
 * Listens to the dynamic route events.
 * Routes in routing.yml are not applicable
 */
class WindRouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    foreach ($collection->all() as $route) {
      if($collection->get('private_message.private_message_page') == $route){
        $route->setPath('');
        // Re-add the collection to override the existing route.
        $collection->add('private_message.private_message_page', $route);
      }
    }
  }
}
