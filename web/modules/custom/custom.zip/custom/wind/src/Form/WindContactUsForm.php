<?php

namespace Drupal\wind\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class WindContactUsForm extends FormBase{

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'wind_contact_us_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $sessionAccountProxy = $this->currentUser();
    $form['full_name'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Full Name'),
      '#required' => TRUE
    );

    if ($sessionAccountProxy->isAuthenticated()) {
      $user = \Drupal\user\Entity\User::load($sessionAccountProxy->id());
      $form['full_name']['#default_value'] = $user->get('field_user_first_name')->isEmpty() ? '' : $user->get('field_user_first_name')->value;
      $form['full_name']['#default_value'] .= $user->get('field_user_last_name')->isEmpty() ? '' : ' ' . $user->get('field_user_last_name')->value;
    }

    $form['email'] = array(
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE
    );

    if ($sessionAccountProxy->isAuthenticated()) {
      $form['email']['#default_value'] = $sessionAccountProxy->getEmail();
    }

    $form['message'] = array(
      '#type' => 'textarea',
      '#title' => $this->t('Message'),
      '#required' => TRUE
    );

    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#button_type' => 'primary'
    );

    return $form;
  }

  /**
   * @param array $form
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $params = [
      'full_name' => $form_state->getValue('full_name'),
      'email' => $form_state->getValue('email'),
      'message' => $form_state->getValue('message'),
    ];
    /** @var \Drupal\Core\Mail\MailManager $mailManager */
    $mailManager = \Drupal::service('plugin.manager.mail');
    $langCode = 'en';
    $mailManager->mail('wind', 'site_contact_form', 'quan.ngo@windwalker.com', $langCode, $params);
  }
}