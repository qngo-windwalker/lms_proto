<?php

namespace Drupal\wind\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class WindAdminConfigEmailForm extends ConfigFormBase{
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'wind_config_email';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'wind.settings.email',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
//    $config = $this->config('wind.settings');

    $form['recipient'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Email Recipent'),
//      '#default_value' => $config->get('site_contact_form_recipient'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('wind.settings.email')
      ->set('site_contact_form_recipient', (bool) $form_state->getValue('recipient'))
      ->save();

    parent::submitForm($form, $form_state);
  }
}
