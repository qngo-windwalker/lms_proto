<?php

namespace Drupal\wind\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;


/**
 * Provides a 'WindIntroBlock' block.
 *
 * @Block(
 *  id = "wind_intro_block",
 *  admin_label = @Translation("Introduction"),
 * )
 */
class WindIntroBlock extends BlockBase {

  private $defaultBodyContent = '<h3>Welcome</h3><p>Need help where to start? Check out the <a href="#">Starter Guide</a>. </p>';

  public function __construct(array $configuration, $plugin_id, $plugin_definition) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $user = \Drupal::currentUser();
    $account = \Drupal\user\Entity\User::load($user->id());
    $userFullName = '';
    if($account->hasField('field_first_name')){
      $userFullName .= $account->get('field_first_name')->getString();
    }
      // Commentted out for now to keep it clean.
//    if($account->hasField('field_last_name')){
//      $userFullName .= ' ' . $account->get('field_last_name')->getString();
//    }

    if ($userFullName) {
      $intro = 'Welcome to your Dashboard, ' . $userFullName . '!';
    } else {
      $intro = 'Welcome to your Dashboard!';
    }

    $this->defaultBodyContent = '<h3>' . $intro . '</h3><p>Need help where to start? Check out the <a href="#">Starter Guide</a>. </p>';
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $title = $this->getConfigValue('label', 'Introduction');
    $content = $this->getConfigValue('body', $this->defaultBodyContent);
    $build['#theme'] = 'wind_bootstrap_block_card';
    $build['#label'] = $title;
    $build['#content'] = $content;
    return $build;
  }

  /**
   * {@inheritdoc}
   */
//  protected function blockAccess(AccountInterface $account) {
//    /** @var \Drupal\Core\Entity\EntityInterface $entity */
//    $entity = $this->getContextValue('entity');
//    // Make sure we have access to the entity.
//    $access = $entity->access('view', $account, TRUE);
//    if ($access->isAllowed()) {
//      // Check that the entity in question has this field.
//      if ($entity instanceof FieldableEntityInterface && $entity->hasField($this->fieldName)) {
//        // Check field access.
//        $field_access = $this->entityTypeManager
//          ->getAccessControlHandler($this->entityTypeId)
//          ->fieldAccess('view', $this->getFieldDefinition(), $account);
//
//        if ($field_access) {
//          // Build a renderable array for the field.
//          $build = $entity->get($this->fieldName)->view($this->configuration['formatter']);
//          // If there are actual renderable children, grant access.
//          if (Element::children($build)) {
//            return AccessResult::allowed();
//          }
//        }
//      }
//      // Entity doesn't have this field, so access is denied.
//      return AccessResult::forbidden();
//    }
//    // If we don't have access to the entity, return the forbidden result.
//    return $access;
//  }

  /**
   * {@inheritdoc}
   */
//  public function access(AccountInterface $account, $return_as_object = FALSE) {
//    return $account->hasPermission('administer site configuration');
//  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $formState) {
    $form = parent::blockForm($form, $formState);
    $form['body'] = array(
      '#type' => 'textarea',
      '#title' => t('Body'),
      '#default_value' => $this->getConfigValue('body', $this->defaultBodyContent)
    );

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $formState) {
    $this->configuration['body'] = $formState->getValue('body');

    return $form;
  }

  public function getCacheMaxAge() {
    return 0;
  }

  private function getConfigValue($key, $defaultValue) {
    return (isset($this->configuration[$key]) && $this->configuration[$key]) ? $this->configuration[$key] : $defaultValue;
  }

}
